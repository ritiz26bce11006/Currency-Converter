# build_report.py
# Builds the project report PDF.
# 1. Change the details below   2. Put your screenshots in ../screenshots/   3. Run: python build_report.py
import os
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import cm
from reportlab.lib import colors
from reportlab.platypus import (CondPageBreak, KeepTogether, SimpleDocTemplate, Paragraph, Spacer, PageBreak,
                                Image, Table, TableStyle, Preformatted)

# ---------- CHANGE THESE ----------
STUDENT_NAME = "Your Name"
REG_NO = "Your Registration No."
COURSE = "Your Course Name / Code"
FACULTY = "Faculty Name"
GITHUB_LINK = "https://github.com/your-username/currency-converter"
# ----------------------------------

styles = getSampleStyleSheet()
H1 = styles["Heading1"]
H2 = styles["Heading2"]
BODY = ParagraphStyle("body", parent=styles["Normal"], fontSize=11, leading=16, spaceAfter=6)
CODE = ParagraphStyle("code", parent=styles["Code"], fontSize=8, leading=10, backColor=colors.whitesmoke)
CENTER = ParagraphStyle("c", parent=BODY, alignment=1)

story = []


def h1(t): story.append(Paragraph(t, H1))
def h2(t): story.append(Paragraph(t, H2))
def p(t): story.append(Paragraph(t, BODY))


def bullets(items):
    for i in items:
        story.append(Paragraph("&bull; " + i, BODY))


def table(data, widths=None):
    # wrap the text of every cell first so long text goes to the next line
    for row in range(len(data)):
        for col in range(len(data[row])):
            data[row][col] = Paragraph(str(data[row][col]), ParagraphStyle("t", fontSize=9, leading=11))
    t = Table(data, colWidths=widths, repeatRows=1)
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#dbeafe")),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
    ]))
    story.append(t)
    story.append(Spacer(1, 10))


def image(path, width=15 * cm, max_h=21 * cm):
    if not os.path.exists(path):
        p(f"<i>[Image not found: {path}]</i>")
        return
    from reportlab.lib.utils import ImageReader
    w, h = ImageReader(path).getSize()
    ratio = w / h
    width = min(width, max_h * ratio)
    story.append(Image(path, width=width, height=width / ratio))
    story.append(Spacer(1, 8))


def fig(title, path, width=15 * cm, max_h=21 * cm):
    """heading and image together so the heading is not left alone at page end"""
    before = len(story)
    h2(title)
    image(path, width, max_h)
    items = story[before:]
    del story[before:]
    story.append(KeepTogether(items))


# ---------------- 1. COVER PAGE ----------------
story.append(Spacer(1, 4 * cm))
story.append(Paragraph("VITyarthi - Build Your Own Project", CENTER))
story.append(Spacer(1, 1 * cm))
story.append(Paragraph("<font size=26><b>World Currency Converter</b></font>", CENTER))
story.append(Spacer(1, 0.5 * cm))
story.append(Paragraph("Project Report", CENTER))
story.append(Spacer(1, 3 * cm))
for line in [f"<b>Name:</b> {STUDENT_NAME}", f"<b>Registration No.:</b> {REG_NO}",
             f"<b>Course:</b> {COURSE}", f"<b>Faculty:</b> {FACULTY}",
             f"<b>GitHub:</b> {GITHUB_LINK}"]:
    story.append(Paragraph(line, CENTER))
story.append(PageBreak())

# ---------------- 2. INTRODUCTION ----------------
h1("1. Introduction")
p("Money conversion is something we need very often when we travel, shop from foreign websites or work with "
  "people from other countries. The exchange rate changes every day, so we cannot depend on old values. "
  "In this project I made a console based Python program called <b>World Currency Converter</b>. It takes "
  "the latest exchange rate from an online API and converts the amount that the user enters. The program "
  "also saves the earlier conversions in a file so that they can be seen again later.")
p("The project uses the Python concepts learned in the course: variables, input/output, conditions, loops, "
  "functions, dictionaries, lists, file handling, exception handling and modules.")

h1("2. Problem Statement")
p("Users need a quick and simple way to know the value of one currency in another currency using the latest "
  "rates. Many online converters contain too many advertisements and do not keep a record of the "
  "conversions. Manual calculation with old rates gives wrong results. The problem is to build a simple "
  "tool which gets the live rate, checks the user input properly, shows the result clearly and stores "
  "the history.")

h2("Objectives")
bullets([
    "To convert an amount between different currencies using live exchange rates.",
    "To validate user input so that the program does not crash on wrong data.",
    "To store the conversion history permanently in a file.",
    "To divide the program into small modules so it is easy to understand and maintain.",
    "To test the important parts of the program using unit tests.",
])

# ---------------- 3. FUNCTIONAL REQUIREMENTS ----------------
h1("3. Functional Requirements")
table([
    ["ID", "Requirement", "Module"],
    ["FR1", "The user can convert an amount from one currency to another using the latest rate.", "converter.py, api_handler.py"],
    ["FR2", "The user can see the list of supported currencies with names and symbols.", "currencies.py"],
    ["FR3", "The user can search a currency using its name or code.", "currencies.py"],
    ["FR4", "Every conversion is saved in the history file with date and time.", "history_manager.py"],
    ["FR5", "The user can view and clear the history.", "history_manager.py"],
    ["FR6", "The program checks the currency codes and amount before conversion.", "validator.py"],
], [1.3 * cm, 10.5 * cm, 4.7 * cm])
p("<b>Major functional modules:</b> (1) Currency Conversion, (2) Currency List and Search, "
  "(3) History Management.")
p("<b>Input:</b> menu choice, FROM code, TO code, amount. <b>Output:</b> converted amount, exchange rate, "
  "history list and messages.")

# ---------------- 4. NON-FUNCTIONAL ----------------
story.append(CondPageBreak(6 * cm))
h1("4. Non-Functional Requirements")
table([
    ["Type", "Requirement"],
    ["Usability", "Simple numbered menu and clear messages so a new user can use it without help."],
    ["Reliability", "The program should not crash on wrong input, no internet or a bad API response."],
    ["Performance", "A conversion should finish within the 10 second timeout; normally it takes about one second."],
    ["Maintainability", "Code is split into small modules with comments; settings are in config.py."],
    ["Error handling", "try/except blocks are used for input conversion, network calls and file reading."],
    ["Logging", "Program events and errors are written in app.log."],
    ["Resource efficiency", "History is limited to the latest 50 records so the file stays small."],
], [4 * cm, 12.5 * cm])

# ---------------- 5. SYSTEM ARCHITECTURE ----------------
h1("5. System Architecture")
p("The program follows a simple layered design. The user talks to <b>main.py</b>, which calls the feature "
  "modules. The feature modules use helper modules for validation, API access, storage and logging.")
image("diagrams/architecture.png")

# ---------------- 6. DESIGN DIAGRAMS ----------------
story.append(PageBreak())
h1("6. Design Diagrams")
fig("6.1 Use Case Diagram", "diagrams/usecase.png", 14 * cm)
fig("6.2 Workflow Diagram", "diagrams/workflow.png", 11 * cm, 18 * cm)
fig("6.3 Sequence Diagram", "diagrams/sequence.png", 16 * cm)
fig("6.4 Component / Class Diagram (project uses functions and modules, so a component diagram is used)", "diagrams/component.png", 16 * cm)
h2("6.5 ER Diagram and Storage Design")
p("The history is stored in <b>history.json</b> as a list of records. Each record has these fields:")
table([
    ["Field", "Type", "Example"],
    ["time", "string (primary key)", "30-09-2026 14:20:10"],
    ["from", "string", "USD"],
    ["to", "string", "INR"],
    ["amount", "float", "100.0"],
    ["result", "float", "8345.5"],
], [4 * cm, 5 * cm, 6 * cm])
image("diagrams/er.png", 11 * cm)

# ---------------- 7. DESIGN DECISIONS ----------------
h1("7. Design Decisions and Rationale")
bullets([
    "<b>Console application:</b> the syllabus is about core Python, so I focused on logic instead of a GUI.",
    "<b>Frankfurter API:</b> it is free and needs no API key. It uses European Central Bank data. "
    "The disadvantage is that it supports only about 30 major currencies, so my list contains only those.",
    "<b>Many small modules:</b> each file has one job, which makes debugging and testing easier.",
    "<b>JSON file for history:</b> a database is not needed for such small data and JSON is easy to read.",
    "<b>Dictionary for currencies:</b> lookup by code is fast and it stores name and symbol together.",
    "<b>Rate = 1 for same currency:</b> the API gives an error when both currencies are same, so the program "
    "handles this case itself.",
])

# ---------------- 8. IMPLEMENTATION ----------------
h1("8. Implementation Details")
table([
    ["File", "Purpose"],
    ["main.py", "Shows the menu in a while loop and calls the correct function."],
    ["converter.py", "Takes input, validates it, gets the rate, calculates and prints the result."],
    ["currencies.py", "Dictionary of currencies, list display, search and name lookup."],
    ["api_handler.py", "Sends the request using the requests library and returns the rate or None."],
    ["validator.py", "Checks currency code and amount (text, negative, nan, inf)."],
    ["history_manager.py", "Reads/writes history.json, shows and clears history."],
    ["logger_setup.py", "Configures logging to app.log."],
    ["config.py", "API URL, timeout, file names and history limit."],
    ["tests/", "Three unit test files (15 tests)."],
], [4 * cm, 12.5 * cm])
p("<b>Main logic of the conversion:</b>")
story.append(Preformatted(
"""from_currency = clean_code(input("Enter FROM currency code: "))
...
if from_currency == to_currency:
    rate = 1.0
else:
    rate = get_rate(from_currency, to_currency)
    if rate is None:
        print("Could not get the exchange rate.")
        return

result = calculate_result(amount, rate)
add_record(from_currency, to_currency, amount, result)""", CODE))
story.append(Spacer(1, 8))
p("<b>Version control:</b> the project was developed with Git and uploaded to GitHub with separate commits "
  f"for each module. Repository: {GITHUB_LINK}")

# ---------------- 9. SCREENSHOTS ----------------
story.append(PageBreak())
h1("9. Screenshots / Results")
shots = [("01_menu.png", "Main menu"), ("02_convert.png", "Currency conversion"),
         ("03_list.png", "Currency list"), ("04_search.png", "Search currency"),
         ("05_history.png", "Conversion history"), ("06_errors.png", "Error handling"),
         ("07_tests.png", "Unit tests running")]
found = False
for f, cap in shots:
    path = os.path.join("..", "screenshots", f)
    if os.path.exists(path):
        found = True
        p(f"<b>{cap}</b>")
        image(path, 14 * cm, 9 * cm)
if not found:
    p("<i>No screenshots found. Save your screenshots in the screenshots folder using the names "
      "01_menu.png, 02_convert.png, 03_list.png, 04_search.png, 05_history.png, 06_errors.png, "
      "07_tests.png and run this script again.</i>")

# ---------------- 10. TESTING ----------------
h1("10. Testing Approach")
p("Two types of testing were done.")
p("<b>a) Unit tests (automatic):</b> written with Python's <i>unittest</i> module. 15 tests check the "
  "validator, calculation, search and the history file. They do not need internet. Run with: "
  "<i>python -m unittest discover -s tests -t . -v</i>")
p("<b>b) Manual tests:</b>")
table([
    ["No.", "Input", "Expected result"],
    ["1", "USD to INR, amount 100", "Shows converted value and the exchange rate"],
    ["2", "USD to USD, amount 50", "50.00 and rate 1.000000 (no API call)"],
    ["3", "FROM code = XYZ", "Invalid FROM currency code."],
    ["4", "Amount = abc", "Please enter a valid positive number."],
    ["5", "Amount = -20", "Please enter a valid positive number."],
    ["6", "Internet turned off", "Could not get the exchange rate message, program continues"],
    ["7", "Menu choice = 9", "Invalid choice. Please select 1-6."],
    ["8", "Search 'yen'", "JPY - Japanese Yen"],
    ["9", "Close and reopen, choose history", "Old conversions are still shown"],
], [1.3 * cm, 6 * cm, 9.2 * cm])

# ---------------- 11. CHALLENGES ----------------
h1("11. Challenges Faced")
bullets([
    "In my first version I listed many currencies (like AED, BDT, PKR) but the API does not support "
    "them, so the program failed for those codes. I had to reduce the list to the supported currencies.",
    "The API gives an error when FROM and TO currency are the same, so I added a special case.",
    "The first version lost the history when the program closed. I solved this by saving to a JSON file.",
    "Everything was in one file and became difficult to manage, so I divided it into modules.",
    "Writing tests for a program that uses the internet was difficult, so I kept calculation and "
    "validation in separate functions that can be tested without the API.",
])

# ---------------- 12. LEARNINGS ----------------
h1("12. Learnings and Key Takeaways")
bullets([
    "How to call a web API and read JSON data using the requests library.",
    "Importance of validating user input and using try/except.",
    "How to divide a program into modules with proper folder structure.",
    "How to read and write files and use the logging module.",
    "How to write unit tests and use Git/GitHub.",
])

# ---------------- 13. FUTURE ----------------
h1("13. Future Enhancements")
bullets([
    "Add a graphical interface using Tkinter or a web version using Flask.",
    "Show a graph of rate change over the last days (the API supports history).",
    "Add support for more currencies using another API.",
    "Save last rates so basic conversion works offline.",
    "Add favourite currency pairs.",
])

# ---------------- 14. REFERENCES ----------------
h1("14. References")
bullets([
    "Frankfurter API documentation - https://www.frankfurter.app/docs/",
    "Python documentation - https://docs.python.org/3/",
    "Requests library documentation - https://requests.readthedocs.io/",
    "Python unittest documentation - https://docs.python.org/3/library/unittest.html",
    "VITyarthi course material",
])


def page_number(canvas, doc):
    canvas.setFont("Helvetica", 8)
    canvas.drawCentredString(A4[0] / 2, 1 * cm, f"World Currency Converter - Page {doc.page}")


doc = SimpleDocTemplate("Project_Report.pdf", pagesize=A4, leftMargin=2 * cm, rightMargin=2 * cm,
                        topMargin=2 * cm, bottomMargin=2 * cm, title="World Currency Converter - Project Report")
doc.build(story, onLaterPages=page_number)
print("Project_Report.pdf created")
