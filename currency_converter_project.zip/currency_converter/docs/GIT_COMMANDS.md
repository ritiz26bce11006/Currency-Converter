# Git steps (for my own reference)

git init
git add config.py currencies.py
git commit -m "Add config and currency data"
git add validator.py logger_setup.py
git commit -m "Add validator and logger"
git add api_handler.py
git commit -m "Add API handler"
git add history_manager.py
git commit -m "Add history saving in json file"
git add converter.py main.py
git commit -m "Add converter and main menu"
git add tests
git commit -m "Add unit tests"
git add README.md statement.md requirements.txt .gitignore docs
git commit -m "Add documentation"
git branch -M main
git remote add origin <repo link>
git push -u origin main
