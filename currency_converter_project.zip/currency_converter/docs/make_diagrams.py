# make_diagrams.py - draws the design diagrams used in the report
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Ellipse, Rectangle, Polygon

OUT = "diagrams/"


def new(w, h):
    fig, ax = plt.subplots(figsize=(w, h))
    ax.set_xlim(0, w * 10)
    ax.set_ylim(0, h * 10)
    ax.axis("off")
    return fig, ax


def box(ax, x, y, w, h, text, color="#dbeafe", fs=9):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.3", fc=color, ec="black"))
    ax.text(x + w / 2, y + h / 2, text, ha="center", va="center", fontsize=fs)


def arrow(ax, x1, y1, x2, y2, text="", dashed=False):
    ax.annotate("", xy=(x2, y2), xytext=(x1, y1),
                arrowprops=dict(arrowstyle="->", lw=1.2, ls="--" if dashed else "-"))
    if text:
        ax.text((x1 + x2) / 2, (y1 + y2) / 2 + 1, text, ha="center", fontsize=8)


# 1. System architecture
fig, ax = new(10, 8)
box(ax, 35, 72, 30, 6, "User (Console)", "#fde68a")
box(ax, 25, 58, 50, 7, "main.py  (menu / program loop)", "#bfdbfe")
box(ax, 3, 40, 26, 8, "converter.py\nConversion module", "#bbf7d0")
box(ax, 37, 40, 26, 8, "currencies.py\nList & Search module", "#bbf7d0")
box(ax, 71, 40, 26, 8, "history_manager.py\nHistory module", "#bbf7d0")
box(ax, 3, 22, 26, 8, "validator.py\napi_handler.py", "#fecaca")
box(ax, 71, 22, 26, 8, "history.json\n(storage)", "#e9d5ff")
box(ax, 3, 4, 26, 8, "Frankfurter API\n(external)", "#fed7aa")
box(ax, 37, 4, 26, 8, "logger_setup.py\napp.log", "#e5e7eb")
arrow(ax, 50, 72, 50, 65)
for x in (16, 50, 84):
    arrow(ax, 50, 58, x, 48)
arrow(ax, 16, 40, 16, 30)
arrow(ax, 16, 22, 16, 12, "HTTP GET")
arrow(ax, 84, 40, 84, 30)
arrow(ax, 29, 24, 37, 10, "logs", True)
arrow(ax, 71, 24, 63, 10, "logs", True)
ax.set_title("System Architecture Diagram", fontweight="bold")
fig.savefig(OUT + "architecture.png", dpi=150, bbox_inches="tight"); plt.close(fig)

# 2. Workflow diagram
fig, ax = new(8, 12)
def diamond(x, y, w, h, text):
    ax.add_patch(Polygon([(x, y + h / 2), (x + w / 2, y + h), (x + w, y + h / 2), (x + w / 2, y)], fc="#fef9c3", ec="black"))
    ax.text(x + w / 2, y + h / 2, text, ha="center", va="center", fontsize=8)
box(ax, 25, 108, 30, 6, "Start", "#bbf7d0")
box(ax, 22, 96, 36, 6, "Enter FROM code, TO code, amount", "#dbeafe", 8)
diamond(20, 80, 40, 10, "Codes valid?")
diamond(20, 64, 40, 10, "Amount valid?")
diamond(20, 48, 40, 10, "FROM == TO?")
box(ax, 22, 33, 36, 6, "Get rate from API", "#dbeafe", 8)
diamond(20, 17, 40, 10, "Rate received?")
box(ax, 22, 3, 36, 8, "Calculate, show result,\nsave in history", "#bbf7d0", 8)
box(ax, 63, 82, 15, 6, "Show error", "#fecaca")
arrow(ax, 40, 108, 40, 102)
arrow(ax, 40, 96, 40, 90)
arrow(ax, 40, 80, 40, 74, "yes")
arrow(ax, 40, 64, 40, 58, "yes")
arrow(ax, 40, 48, 40, 39, "no")
arrow(ax, 40, 33, 40, 27)
arrow(ax, 40, 17, 40, 11, "yes")
arrow(ax, 60, 85, 63, 85, "no")
arrow(ax, 60, 69, 70, 82, "no")
arrow(ax, 60, 22, 76, 82, "no")
arrow(ax, 60, 53, 58.3, 8)
ax.text(62, 40, "yes\n(rate = 1)", fontsize=8)
ax.set_title("Process / Workflow Diagram (Convert Currency)", fontweight="bold")
fig.savefig(OUT + "workflow.png", dpi=150, bbox_inches="tight"); plt.close(fig)

# 3. Use case diagram
fig, ax = new(10, 7)
ax.add_patch(Rectangle((30, 3), 62, 64, fc="none", ec="black"))
ax.text(61, 63, "World Currency Converter", ha="center", fontweight="bold")
cases = ["Convert currency", "View currency list", "Search currency",
         "View history", "Clear history", "Exit program"]
ys = [54, 44, 34, 24, 14, 6]
for c, y in zip(cases, ys):
    ax.add_patch(Ellipse((55, y), 34, 7, fc="#dbeafe", ec="black"))
    ax.text(55, y, c, ha="center", va="center", fontsize=9)
    ax.plot([9, 38], [35, y], color="gray", lw=1)
ax.add_patch(Ellipse((80, 54), 20, 7, fc="#fef9c3", ec="black"))
ax.text(80, 54, "Get live rate", ha="center", va="center", fontsize=8)
ax.plot([72, 72], [54, 54], color="gray")
ax.text(9, 43, "O", ha="center", fontsize=16); ax.plot([9, 9], [37, 42], "k"); ax.plot([5, 13], [40, 40], "k")
ax.plot([9, 5], [37, 33], "k"); ax.plot([9, 13], [37, 33], "k")
ax.text(9, 29, "User", ha="center")
box(ax, 95, 30, 4, 12, "", "#fed7aa")
ax.text(97, 26, "API", ha="center", fontsize=8)
ax.annotate("", xy=(90, 54), xytext=(96, 42), arrowprops=dict(arrowstyle="->", ls="--"))
ax.set_xlim(0, 102)
ax.set_title("Use Case Diagram", fontweight="bold")
fig.savefig(OUT + "usecase.png", dpi=150, bbox_inches="tight"); plt.close(fig)

# 4. Sequence diagram
fig, ax = new(11, 8)
names = ["User", "main.py", "converter", "validator", "api_handler", "API", "history_mgr"]
xs = [8, 24, 40, 55, 70, 85, 100]
for n, x in zip(names, xs):
    box(ax, x - 6, 74, 12, 4, n, "#dbeafe", 8)
    ax.plot([x, x], [72, 3], "k--", lw=0.6)
msgs = [
    (0, 1, 68, "choose 1"),
    (1, 2, 63, "convert_currency()"),
    (0, 2, 58, "codes + amount"),
    (2, 3, 53, "validate"),
    (3, 2, 48, "valid / None"),
    (2, 4, 43, "get_rate()"),
    (4, 5, 38, "HTTP GET"),
    (5, 4, 33, "JSON rate"),
    (4, 2, 28, "rate"),
    (2, 6, 23, "add_record()"),
    (2, 0, 15, "show result"),
]
for a, b, y, t in msgs:
    arrow(ax, xs[a], y, xs[b], y)
    ax.text((xs[a] + xs[b]) / 2, y + 1.3, t, ha="center", fontsize=7)
ax.set_xlim(0, 110)
ax.set_title("Sequence Diagram (Convert Currency)", fontweight="bold")
fig.savefig(OUT + "sequence.png", dpi=150, bbox_inches="tight"); plt.close(fig)

# 5. Component diagram
fig, ax = new(11, 7)
comps = {
    "main.py": (40, 58, "main()\nsearch_menu()"),
    "converter.py": (5, 38, "convert_currency()\ncalculate_result()"),
    "history_manager.py": (40, 38, "load_history()\nsave_history()\nadd_record()\nshow_history()\nclear_history()"),
    "currencies.py": (75, 38, "show_currencies()\nsearch_currency()\nget_name()"),
    "validator.py": (5, 14, "is_valid_currency()\nget_valid_amount()\nclean_code()"),
    "api_handler.py": (40, 14, "get_rate()"),
    "config.py": (75, 14, "API_URL, HISTORY_FILE,\nLOG_FILE ..."),
}
for n, (x, y, f) in comps.items():
    ax.add_patch(Rectangle((x, y), 30, 16, fc="#dbeafe", ec="black"))
    ax.plot([x, x + 30], [y + 12, y + 12], "k", lw=0.8)
    ax.text(x + 15, y + 14, n, ha="center", va="center", fontsize=8, fontweight="bold")
    ax.text(x + 15, y + 6, f, ha="center", va="center", fontsize=7)
for tx in (20, 55, 90):
    arrow(ax, 55, 58, tx, 54)
arrow(ax, 20, 38, 20, 30)
arrow(ax, 30, 44, 40, 44)
arrow(ax, 20, 38, 50, 30)
arrow(ax, 55, 38, 55, 30, "", True)
arrow(ax, 70, 22, 75, 22, "", True)
ax.set_xlim(0, 110)
ax.set_ylim(5, 82)
ax.set_title("Component / Class Diagram (module dependencies)", fontweight="bold")
fig.savefig(OUT + "component.png", dpi=150, bbox_inches="tight"); plt.close(fig)

# 6. ER diagram
fig, ax = new(8, 5)
ax.add_patch(Rectangle((30, 25), 20, 8, fc="#dbeafe", ec="black"))
ax.text(40, 29, "CONVERSION_HISTORY", ha="center", va="center", fontsize=8, fontweight="bold")
attrs = ["time (PK)", "from", "to", "amount", "result"]
pos = [(8, 42), (35, 44), (62, 42), (10, 12), (62, 12)]
for a, (x, y) in zip(attrs, pos):
    ax.add_patch(Ellipse((x + 6, y), 14, 6, fc="#fef9c3", ec="black"))
    ax.text(x + 6, y, a, ha="center", va="center", fontsize=8)
    ax.plot([x + 6, 40], [y + (-3 if y > 30 else 3), 29 + (4 if y > 30 else 0)], "gray", lw=0.8)
ax.set_xlim(0, 80); ax.set_ylim(0, 50)
ax.set_title("ER Diagram (history.json stores a list of these records)", fontweight="bold", fontsize=9)
fig.savefig(OUT + "er.png", dpi=150, bbox_inches="tight"); plt.close(fig)
print("diagrams done")
